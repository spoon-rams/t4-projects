document.addEventListener("DOMContentLoaded", () => {
  const slidesContainer = document.querySelector(".slide-container");
  const slide = document.querySelector(".slide");
  const slides = document.querySelectorAll(".slide");
  const prevButton = document.querySelector(".carousel-arrow.prev");
  const nextButton = document.querySelector(".carousel-arrow.next");
  const contentTitle = document.querySelector(".content .title");
  const contentDesc = document.querySelector(".content .description");
  const contentButtonText = document.querySelector(".content .button-text span");

  let startX = 0;
  let clickPending = false;
  let currentSlide = 0;

  //   INITIAL FEATURE RENDER
  if (slides.length > 1) {
    prevButton.style.display = "none";
  } else {
    prevButton.style.display = "none";
    nextButton.style.display = "none";
  }

  contentTitle.innerText = slides[currentSlide].dataset.title;
  contentDesc.innerText = slides[currentSlide].dataset.desc;
  contentButtonText.innerText = slides[currentSlide].dataset.buttonText;

  // DESKTOP CLICK ACTION - NEED TO turn this into a function
  nextButton.addEventListener("click", (e) => {
    if (clickPending) {
      e.stopImmediatePropagation();
      return;
    }
    clickPending = true;
    handleClick("next", slidesContainer, slide);
    setTimeout(() => (clickPending = false), 800);
  });

  prevButton.addEventListener("click", (e) => {
    if (clickPending) {
      e.stopImmediatePropagation();
      return;
    }
    clickPending = true;
    handleClick("previous", slidesContainer, slide);
    setTimeout(() => (clickPending = false), 800);
  });

  // MOBILE VIEW
  //   window.addEventListener("resize", () => {
  //     return handleClick("resize", slidesContainer, slide);
  //   });

  // MOBILE TOUCH ACTION
  slidesContainer.addEventListener("touchstart", (e) => {
    startX = e.touches[0].clientX;
  });

  slidesContainer.addEventListener("touchend", (e) => {
    var endX = e.changedTouches[0].clientX;
    var deltaX = startX - endX;

    // Set a threshold for swipe distance
    var swipeThreshold = 50;

    if (deltaX > swipeThreshold) {
      // Swipe left, scroll to the next box
      if (currentSlide < slides.length - 1) {
        currentSlide++;
        setButton(currentSlide);
      }
    } else if (deltaX < -swipeThreshold) {
      // Swipe right, scroll to the previous box
      if (currentSlide > 0) {
        currentSlide--;
        setButton(currentSlide);
      }
    }

    // Calculate the scroll position based on the current index
    var scrollPosition = slides[currentSlide].offsetLeft - slidesContainer.offsetLeft;

    // Scroll to the selected box with a smooth animation
    slidesContainer.scrollTo({
      left: scrollPosition,
      behavior: "smooth",
    });
  });
});

let currentSlide = 0;
// HELPER FUNCTION - SETS THE INDICATOR DOT - Refactoring
function setButton(index) {
  const prevButton = document.querySelector(".carousel-arrow.prev");
  const nextButton = document.querySelector(".carousel-arrow.next");
  const slides = document.querySelectorAll(".slide");
  const contentTitle = document.querySelector(".content .title");
  const contentDesc = document.querySelector(".content .description");
  const contentButtonText = document.querySelector(".content .button-text span");

  // Hides Previous Button
  if (index === 0) {
    prevButton.style.display = "none";
  } else {
    prevButton.style.display = "block";
  }

  // Hides Next Button
  if (index === slides.length - 1) {
    nextButton.style.display = "none";
  } else {
    nextButton.style.display = "block";
  }

  contentTitle.innerText = slides[currentSlide].dataset.title;
  contentDesc.innerText = slides[currentSlide].dataset.desc;
  contentButtonText.innerText = slides[currentSlide].dataset.buttonText;
}

// CLICK ACTION REFACTOR
function handleClick(action, container, slide, index) {
  switch (action) {
    case "next":
      container.scrollLeft += slide.clientWidth;
      currentSlide += 1;
      return setButton(currentSlide);
    case "previous":
      container.scrollLeft -= slide.clientWidth;
      currentSlide -= 1;
      return setButton(currentSlide);
    case "resize":
      //   container.scrollLeft = currentSlide * slide.clientWidth;

      //   const containerWidth = container.clientWidth;
      //   const slideWidth = slide.clientWidth;
      //   const scrollPosition = currentSlide * slideWidth - (containerWidth - slideWidth) / 2;
      container.scrollLeft = 0;
      return setButton(currentSlide);
  }
}
